
function val(){
var username = document.getElementById("username").value;
var password = document.getElementById("password").value;
if ( username != "" && password != ""){
alert("SignUp successfully");
window.location = "Login.html";
return false;
}
else{
alert("Please enter username and password");
}
}